# -*- coding: utf-8 -*-
# -*- Famz____Botz -*-
# -*- version: Bots__Helper v.03 2020 -*-
# -*- creator: Bardian_Syah -*-
from linepy import *
from akad.ttypes import Message
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest
from akad.ttypes import ContentType as Type
from akad.ttypes import TalkException
from famz.thrift.protocol import TCompactProtocol
from famz.thrift.transport import THttpClient
from famz.ttypes import LoginRequest
from datetime import datetime, timedelta
from time import sleep
from bs4 import BeautifulSoup
from humanfriendly import format_timespan, format_size, format_number, format_length
from gtts import gTTS
from threading import Thread
from io import StringIO
from multiprocessing import Pool
from googletrans import Translator
from urllib.parse import urlencode
from wikiapi import WikiApi
from tmp.MySplit import *
from zalgo import zalgoname
from random import randint
from shutil import copyfile
from youtube_dl import YoutubeDL
import LineService
import subprocess, youtube_dl, humanize, traceback
import subprocess as cmd
import time, random, sys, json, null, codecs, html5lib ,shutil ,threading, glob, re, base64, string, os, requests, six, ast, pytz, wikipedia, urllib, urllib.parse, atexit, asyncio, traceback
_session = requests.session()
try:
    import urllib.request as urllib2
except ImportError:
    import urllib2
#=====================================================================
#appF = "ANDROIDLITE\t2.11.1\tAndroid OS\t6.0.1"
bardifamz = LINE("vbYafQuK@be-line.me","BETeam2@")
#=======================================================
waitOpen = codecs.open("wait.json","r","utf-8")
settingsOpen = codecs.open("temp.json","r","utf-8")
tokenOpen = codecs.open("toket.json","r","utf-8")
premiumOpen = codecs.open("user.json","r","utf-8")
#=====================================================================
#=====================================================================
famzProfile = bardifamz.getProfile()
famzSettings = bardifamz.getSettings()
famzPoll = OEPoll(bardifamz)
Famzmid = bardifamz.getProfile().mid
print ("BOSS : " + Famzmid)
#=====================================================================
#=====================================================================
loop = asyncio.get_event_loop()
admin =["ua19b7ef5349d083d65a82f92f8ed596d","ubb9c0d0e7ee50381a68f10ffea16b033"]
famzAdmin = ["ua19b7ef5349d083d65a82f92f8ed596d","ubb9c0d0e7ee50381a68f10ffea16b033"]
botStart = time.time()
msg_dict = {}
temp_flood = {}
groupName = {}
groupImage = {}
kuciyose = {}
protectname = []
wbanlist = []
protectinvite = []
protectkick = []
protectjoin = []
protectqr = []
protectantijs = []
gkuis = []
wait = json.load(waitOpen)
settings = json.load(settingsOpen)
token = json.load(tokenOpen)
premium = json.load(premiumOpen)
responsename = bardifamz.getProfile().displayName
listToken = ['desktopmac','desktopwin','iosipad','chromeos','win10']

kimak= {
    "Addaudio": False,
    "Audio": {},
    "Audios": {
     },
}

hoho = {
    "savefile": False,
    "namefile": "",
}

itil = {
    "blacklist": {},
}

peler = {
    "receivercount": 0,
    "sendcount": 0
}

chatbot = {
    "admin": [],
    "botMute": [],
    "botOff": [],
}

read = {
    "readMember": {},
    "readPoint": {}
}

upfoto = {
    "upfoto": {}
}
#==================================================
try:
    with open("data.json", "r", encoding="utf_8_sig") as fp:
        datakuis = json.loads(fp.read())
except:
    print ("data file not found, data dict default will used")
    datakuis = {}
with open("quest.txt", "r") as file:
     blist = file.readlines()
     quest = [x.strip() for x in blist]
file.close()
group = bardifamz.getGroupIdsJoined()
for g in group:
  datakuis[g]={'point':{}}
  datakuis[g]['saklar']=False
  datakuis[g]['quest']=''
  datakuis[g]['asw']=[]
  datakuis[g]['tmp']=[]
def backupData():
    with open("data.json", "w", encoding="utf8") as f:
        json.dump(datakuis, f, ensure_ascii=False, indent=4, separators=(',', ': '))
#atexit.register(backupData)
def getQuest(to):
	try:
			datakuis[to]['quest'] = ''
			datakuis[to]['asw'] = []
			datakuis[to]['tmp'] = []
			a = random.choice(quest)
			a = a.split('*')
			datakuis[to]['quest'] = a[0]
			for i in range(len(a)):
				datakuis[to]['asw'] += [a[i]]
			datakuis[to]['asw'].remove(a[0])
			for j in range(len(datakuis[to]['asw'])):
				datakuis[to]['tmp'] += [str(j+1)+'. _________']
	except Exception as e:
		print(e)
#==================================================
#=====================================================================
settings["myProfile"]["displayName"] = famzProfile.displayName
settings["myProfile"]["statusMessage"] = famzProfile.statusMessage
settings["myProfile"]["pictureStatus"] = famzProfile.pictureStatus
cont = bardifamz.getContact(Famzmid)
settings["myProfile"]["videoProfile"] = cont.videoProfile
coverId = bardifamz.getProfileDetail()["result"]["objectId"]
settings["myProfile"]["coverId"] = coverId
#=====================================================================
helpMessage2 ="""     ⏭️⏭️ Famz__Botz ⏮️⏮️
╔═══════════════════╗
╠>>>>>Help___Botz<<<<<
╠🇮🇩● kuis on
╠🇮🇩● kuis off
╠🇮🇩● /mulai
╠🇮🇩● /next
╠🇮🇩● /nyerah
╠🇮🇩● /reset
╠🇮🇩● #bye
╠🇮🇩● ping
╠🇮🇩● join on
╠🇮🇩● join off
╠🇮🇩● #name [text]
╠🇮🇩● #upfoto
╠🇮🇩● Addadmin @
╠🇮🇩● Delladmin @
╚═══════════════════╝"""
#=====================================================================
with open("temp.json", "r", encoding="utf_8_sig") as f:
    anu = json.loads(f.read())
    anu.update(settings)
    settings = anu
with open("wait.json", "r", encoding="utf_8_sig") as f:
    itu = json.loads(f.read())
    itu.update(wait)
    wait = itu

def debug():
    get_profile_time_start = time.time()
    get_profile = bardifamz.getProfile()
    get_profile_time = time.time() - get_profile_time_start
    get_group_time_start = time.time()
    get_group = bardifamz.getGroupIdsJoined()
    get_group_time = time.time() - get_group_time_start
    get_contact_time_start = time.time()
    get_contact = bardifamz.getContact(get_profile.mid)
    get_contact_time = time.time() - get_contact_time_start
    elapsed_time = time.time() - get_profile_time_start
    return " 「 Debug 」\n - Send Message\n   %.5f\n - Get Profile\n   %.5f\n - Get Contact\n   %.5f\n - Get Group\n   %.5f" % (elapsed_time,get_profile_time,get_contact_time,get_group_time)
#=====================================================================
def headers2():
    Headers = {
    'User-Agent': "Line/9.21.2",
    'X-Line-Application': "IOSIPAD\t9.22.2\tIPAD\t12.2",
    "x-lal": "ja-US_US",
    }
    return Headers
#=====================================================================
def restartBot():
    print ("[ INFO ] BOT RESETTED")
    backupData()
    python = sys.executable
    os.execl(python, python, *sys.argv)
#=====================================================================
def getToken(to, header="ios_ipad"):
    auth = "tokennya"
    result = json.loads(requests.get("https://api.boteater.us/line_qr_v2?header="+header+"&auth="+auth).text)
    bardifamz.sendMessage(to, "Login IP: {} \nQR Link: {}".format(result["result"]["login_ip"],result["result"]["qr_link"]))
    result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
    if result["status"] != 200:
        raise Exception("Timeout!!!")
    bardifamz.sendMessage(to, "Pincode: "+result["result"]["pin_code"])
    result = json.loads(requests.get(result["result"]["callback"]+"&auth="+auth).text)
    if result["status"] != 200:
        raise Exception("Timeout!!!")
    return result["result"]["token"]
#=====================================================================
def sendMention(to, mid, firstmessage='', lastmessage=''):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@x "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        try:
            bardifamz.sendMessage(to, text, {'MSG_SENDER_NAME': bardifamz.getContact(mid).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + bardifamz.getContact(mid).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
        except Exception as e:
            bardifamz.sendMessage(to, text, {'MSG_SENDER_NAME': bardifamz.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").displayName,'MSG_SENDER_ICON': 'http://dl.profile.line-cdn.net/' + bardifamz.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        print(error)
def mentions(to, text="", mids=[]):
    arrData = ""
    arr = []
    mention = "@KhieGans  "
    if mids == []:
        raise Exception("Invalid mids")
    if "@!" in text:
        if text.count("@!") != len(mids):
            raise Exception("Invalid mids")
        texts = text.split("@!")
        textx = ""
        for mid in mids:
            textx += str(texts[mids.index(mid)])
            slen = len(textx)
            elen = len(textx) + 15
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mid}
            arr.append(arrData)
            textx += mention
        textx += str(texts[len(mids)])
    else:
        textx = ""
        slen = len(textx)
        elen = len(textx) + 15
        arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
        arr.append(arrData)
        textx += mention + str(text)
    bardifamz.sendMessage(to, textx, {'AGENT_NAME':'LINE OFFICIAL', 'AGENT_LINK': 'line://ti/p/~{}'.format(bardifamz.getProfile().userid), 'AGENT_ICON': "http://dl.profile.line-cdn.net/" + bardifamz.getContact("u085311ecd9e3e3d74ae4c9f5437cbcb5").picturePath, 'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = bardifamz.genOBSParams({'oid': Famzmid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = bardifamz.server.postContent('{}/talk/vp/upload.nhn'.format(str(bardifamz.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        bardifamz.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile {}".format(str(e)))
        os.remove("KhieWasHere.mp4")

def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = bardifamz.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)
#=====================================================================
def speedtest(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weaks, days = divmod(days,7)
    if days == 0:
        return '%02d' % (secs)
    elif days > 0 and weaks == 0:
        return '%02d' %(secs)
    elif days > 0 and weaks > 0:
        return '%02d' %(secs)

def change(url):
	import base64
	return base64.b64encode(url.encode()).decode()

def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@MentionOrang "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        bardifamz.sendMessage(to, textx, {'MSG_SENDER_NAME': bardifamz.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + bardifamz.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================
def logError(text):
    bardifamz.log("ERROR 404 !\n" + str(text))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = hasil + ", " + inihari.strftime('%d') + " - " + bln + " - " + inihari.strftime('%Y') + " | " + inihari.strftime('%H:%M:%S')
    with open("errorLog.txt","a") as error:
        error.write("\n[%s] %s" % (str(time), text))
#=====================================================================
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
#=====================================================================
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def backupData():
    try:
        backup = settings
        f = codecs.open('temp.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = wait
        f = codecs.open('wait.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = premium
        f = codecs.open('user.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
#=====================================================================
async def khieBot(op):
    try:
        if settings["restartPoint"] != None:
            bardifamz.sendMessage(settings["restartPoint"], 'Activated♪')
            settings["restartPoint"] = None
        if op.type == 0:
            return

        if op.type in [22,24]:
            bardifamz.leaveRoom(op.param1)
#=====================================================================
        if op.type == 13 or op.type == 124:
            if Famzmid in op.param3:
                if settings["autoJoin"] == True:
                    if op.param2 not in admin:
                        bardifamz.acceptGroupInvitation(op.param1)
                        datakuis[op.param1] = {
                	        "point": {},
                	        "saklar": False,
                	        "quest": "",
                	        "tmp": [],
                	        "asw": []
                        }
                    else:
                        bardifamz.acceptGroupInvitation(op.param1)
                        datakuis[op.param1] = {
                	        "point": {},
                	        "saklar": False,
                	        "quest": "",
                	        "tmp": [],
                	        "asw": []
                        }

        if op.type in [25, 26]:
            if op.type == 25: print ("[ 25 ] SEND MESSAGE")
            else: print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = msg.text
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            s = bardifamz.getProfile().mid
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False:
               setKey = ''
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                if msg.toType == 0:
                    if sender != bardifamz.profile.mid:
                        to = sender
                    else:
                        to = receiver
                elif msg.toType == 1:
                    to = receiver
                elif msg.toType == 2:
                    to = receiver
                if msg.contentType == 0:
                    if text is None:
                        return
                    else:
                        cmd = command(text)
                        if sender != s:
                	        peler["receivercount"] += 1
                        if sender == s:
                	        peler["sendcount"] += 1
#=====================================================================
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != Famzmid: to = sender
                else: to = receiver
                if msg.contentType == 6:
                    try:
                        contact = bardifamz.getContact(sender)
                        if msg.toType == 2:
                            anu = bardifamz.getGroup(to)
                            if msg.contentMetadata['GC_EVT_TYPE'] == 'S' and msg.contentMetadata['GC_MEDIA_TYPE'] == 'LIVE':
                                anu = msg.contentMetadata={'GC_EVT_TYPE': 'S', 'GC_CHAT_MID': to, 'RESULT': 'INFO', 'SKIP_BADGE_COUNT': 'false', 'GC_IGNORE_ON_FAILBACK': 'false', 'TYPE': 'G', 'DURATION': '0', 'GC_MEDIA_TYPE': 'VIDEO', 'VERSION': 'X', 'CAUSE': '16'}
                    except Exception as e:
                        bardifamz.sendMessage(to, str(e))
        if op.type == 26:
            print ("[ 26 ] RECEIVE MESSAGE")
            msg = op.message
            text = str(msg.text)
            msg_id = msg.id
            receiver = msg.to
            sender = msg._from
            to = msg.to
            cmd = command(text)
            isValid = True
            setKey = settings["keyCommand"].title()
            if settings["setKey"] == False: setKey = ''
            if isValid != False:
                if msg.toType == 0 and sender != Famzmid: to = sender
                else: to = receiver
                if msg.contentType == 14:
                    if hoho["savefile"] == True:
                        try:
                             namafile = hoho["namafile"]
                             bardifamz.downloadObjectMsg(msg_id,saveAs=namafile)
                             hoho["savefile"] = False
                             bardifamz.sendMessage(to, "Successful, the file has been uploaded")
                        except Exception as e:
                         	bardifamz.sendMessage(to, str(e))
                if msg.contentType == 1:
                    if settings["changeCoverProfile"] == True:
                        path = bardifamz.downloadObjectMsg(msg_id)
                        settings["changeCoverProfile"] = False
                        bardifamz.updateProfileCover(path)
                        bardifamz.sendMessage(to,"Cover Image Updated.")
                if msg.contentType == 1:
                   if msg._from in famzAdmin:
                       if Famzmid in upfoto["upfoto"]:
                            path = bardifamz.downloadObjectMsg(msg_id)
                            del upfoto["upfoto"][Famzmid]
                            bardifamz.updateProfilePicture(path)
                            bardifamz.sendMessage(msg.to,"Foto berhasil dirubah")
                if msg.contentType in [0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]:
                    if msg.toType == 0:
                        if settings["autoRead"] == True:
                            bardifamz.sendChatChecked(to, msg_id)
                    if msg.toType == 2:
                        if settings["autoRead1"] == True:
                            bardifamz.sendChatChecked(to, msg_id)
                if msg.contentType == 0:
                    if "/ti/g/" in text.lower():
                        if settings["autoJoin"] == True:
                            link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                            links = link_re.findall(text)
                            n_links = []
                            for l in links:
                                if l not in n_links:
                                   n_links.append(l)
                            for ticket_id in n_links:
                                group = bardifamz.findGroupByTicket(ticket_id)
                                if len(group.members) >= wait["Members"]:
                                    bardifamz.acceptGroupInvitationByTicket(group.id,ticket_id)
                                else:
                                    bardifamz.acceptGroupInvitationByTicket(group.id,ticket_id)
                                    bardifamz.leaveGroup(group.id)
#==========================================
                    elif cmd == "help":
                        bardifamz.sendMessage(to, helpMessage2)
                    elif cmd == "#change cover":
                        if msg._from in famzAdmin:
                            settings["changeCoverProfile"] = True
                            bardifamz.sendMessage(to,"Send a Image to change cover.")
#==========================================
                    if cmd == "kiss me":
                        bardifamz.generateReplyMessage(msg.id)
                        bardifamz.sendReplyMessage(msg.id, to,"。。・゜゜・❤ "+bardifamz.getContact(sender).displayName+" ❤ \n(づ￣ ³￣)づ")
#==========================================
                    elif cmd == "cmd":
                        if msg._from in famzAdmin:
                            ret = "Help Message\n\n"
                            ret += "  • #glist\n"
                            ret += "  • #skill\n"
                            ret += "  • #slain\n"
                            ret += "  • #cvp\n"
                            ret += "  • #debug\n"
                            ret += "  • #speed\n"
                            ret += "  • #bcast\n"
                            ret += "  • #leave"
                            bardifamz.sendMessage(to, "{}".format(str(ret)))
#==========================================
                    elif cmd.startswith("#leave "):
                        if msg._from in famzAdmin:
                            number = removeCmd("#leave", text)
                            groups = bardifamz.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = bardifamz.getGroup(group)
                                try:
                                    bardifamz.leaveGroup(G.id)
                                except:
                                    bardifamz.leaveGroup(G.id)
                                bardifamz.sendMessage(to, "「Leave 」\n\nGroup : " + G.name)
                            except Exception as error:
                                bardifamz.sendMessage(to, str(error))
#==========================================
                    if cmd == "chat maker":
                        bardifamz.sendMention(msg.to, 'Hallo @! if u want chat my creator\nType : Chatmaker [text]\nExample : Chatmaker hi bardi',' ', [msg._from])
                    elif cmd.startswith("chatmaker "):
                        sep = text.split(" ")
                        txt = text.replace(sep[0] + " ","")
                        contact = bardifamz.getContact(sender)
                        owner = "ue00a689c2f2097bea8166b1e318988a4"
                        mat_ = "Sender: @!"
                        mat_ += "\nMessage: {}".format(txt)
                        mat = {
                            'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + contact.pictureStatus,
                            'MSG_SENDER_NAME':  contact.displayName,
                            'mid': sender,
                        }
                        mid = bardifamz.getContact(sender).displayName
                        mentions(owner, mat_, [sender])
                        bardifamz.sendMessage(owner, mid, contentMetadata=mat, contentType=13)
                        bardifamz.sendMention(to, "Hi @!\nYour message has been send ^_^","",[msg._from])
#==========================================
#==========================================
                    elif cmd.startswith("#name "):
                        if msg._from in famzAdmin:
                            string = removeCmd("#name", text)
                            if len(string) <= 10000000000:
                                pname = bardifamz.getContact(sender).displayName
                                profile = bardifamz.getProfile()
                                profile.displayName = string
                                bardifamz.updateProfile(profile)
                                bardifamz.sendMessage(to, "「 Update Name 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif cmd.startswith("#status "):
                        if msg._from in famzAdmin:
                            string = removeCmd("#status", text)
                            if len(string) <= 10000000000:
                                pname = bardifamz.getContact(sender).statusMessage
                                profile = bardifamz.getProfile()
                                profile.statusMessage = string
                                bardifamz.updateProfile(profile)
                                bardifamz.sendMessage(to, "「 Update Status 」\nStatus : Success\nFrom : "+str(pname)+"\nTo :"+str(string))
                    elif cmd == "#upfoto":
                            if msg._from in famzAdmin:
                                upfoto["upfoto"][Famzmid] = True
                                bardifamz.sendMessage(msg.to,"Kirim fotonya.....")
#==========================================
                    elif cmd == "ping":
                        if msg._from in famzAdmin:
                            bardifamz.sendMention(to, "PONG ! @!","",[msg._from])
#==========================================
                    elif cmd == "#join on":
                        if msg._from in famzAdmin:
                            if settings["autoJoin"] == True:
                                msgs=" 「 Join 」\nJoin already Enable♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to Enable♪"
                                settings["autoJoin"] = True
                            bardifamz.sendMessage(to, msgs)
                    elif cmd == "#join off":
                        if msg._from in famzAdmin:
                            if settings["autoJoin"] == False:
                                msgs=" 「 Join 」\nJoin already DISABLED♪"
                            else:
                                msgs=" 「 Join 」\nJoin set to DISABLED♪"
                                settings["autoJoin"] = False
                            bardifamz.sendMessage(to, msgs)
#==========================================
                    elif cmd== '#bye':
                        if msg._from in famzAdmin:
                            bardifamz.leaveGroup(to)
                    elif cmd.startswith("#getcontact "):
                        if msg._from in famzAdmin:
                               sep = text.split(" ")
                               txt = text.replace(sep[0] + " ","")
                               msg.contentType = 13
                               msg.contentMetadata = {'mid': txt}
                               bardifamz.sendMessage1(msg)
#==========================================
                    elif cmd.startswith("#skill "):
                        if msg._from in famzAdmin:
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = bardifamz.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = bardifamz.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return bardifamz.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               bardifamz.kickoutFromGroup(msg.to,[target])
                    elif cmd.startswith("#slain "):
                        if msg._from in famzAdmin:
                           sep = text.split(" ")
                           midn = text.replace(sep[0] + " ","")
                           hmm = text.lower()
                           G = bardifamz.getGroup(msg.to)
                           members = [G.mid for G in G.members]
                           targets = []
                           for x in members:
                               contact = bardifamz.getContact(x)
                               msg = op.message
                               testt = contact.displayName.lower()
                                   #print(testt)
                               if midn in testt:targets.append(contact.mid)
                           if targets == []:return bardifamz.sendMessage(to,"not found name "+midn)
                           for target in targets:
                               bardifamz.kickoutFromGroup(msg.to,[target])
                               bardifamz.findAndAddContactsByMid(target)
                               bardifamz.inviteIntoGroup(msg.to, [target])
                               bardifamz.cancelGroupInvitation(msg.to, [target])
                               time.sleep(5)
                               bardifamz.inviteIntoGroup(msg.to, [target])
#==========================================
                    elif cmd.startswith("#cvp"):
                        if msg._from in famzAdmin:
                            link = removeCmd("helper:cvp", text)
                            contact = bardifamz.getContact(sender)
                            bardifamz.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Download...")
                            print("Sedang Mendownload Data ~")
                            pic = "http://dl.profile.line-cdn.net/{}".format(contact.pictureStatus)
                            subprocess.getoutput('youtube-dl --format mp4 --output TeamAnuBot.mp4 {}'.format(link))
                            pict = bardifamz.downloadFileURL(pic)
                            vids = "TeamAnuBot.mp4"
                            time.sleep(2)
                            changeVideoAndPictureProfile(pict, vids)
                            bardifamz.sendMessage(to, "Type: Profile\n • Detail: Change video url\n • Status: Succes")
                            os.remove("TeamAnuBot.mp4")
#==========================================
                    elif cmd == "#debug":
                       if msg._from in famzAdmin:
                            bardifamz.sendMessage(to, debug())
                    elif cmd == "#login qr":
                            bardifamz.sendMessage(to, getToken())
                    elif cmd == "speed":
                        start = time.time()
                        bardifamz.sendMessage("ue00a689c2f2097bea8166b1e318988a4", '</>')
                        elapsed_time = time.time() - start
                        bardifamz.sendMessage(to,"Time:\n%s"%str(round(elapsed_time,5)))
#==========================================
                    elif cmd == "#glist":
                       if msg._from in famzAdmin:
                            key = settings["keyCommand"].title()
                            if settings['setKey'] == False:key = ''
                            gid = bardifamz.getGroupIdsJoined()
                            sd = bardifamz.getGroups(gid)
                            ret = "「 Group List 」\n"
                            no = 0
                            total = len(gid)
                            cd = "\n\nTotal {} Groups\n".format(total)
                            for G in sd:
                                member = len(G.members)
                                no += 1
                                ret += "\n{}. {} {}".format(no, G.name[0:20], member)
                            ret += cd
                            k = len(ret)//10000
                            for aa in range(k+1):
                                bardifamz.generateReplyMessage(msg.id)
                                bardifamz.sendReplyMessage(msg.id, to,'{}'.format(ret[aa*10000 : (aa+1)*10000]))
                    elif cmd.startswith("#bcast"):
                      if msg._from in famzAdmin:
                        tod = text.split(" ")
                        hey = text.replace(tod[0] + " ", "")
                        text = "{}".format(hey)
                        groups = bardifamz.getGroupIdsJoined()
                        friends = bardifamz.getAllContactIds()
                        for gr in groups:
                            bardifamz.sendMessage(to, "Succes Group cast to {} group ".format(str(len(groups))))
                    elif cmd.startswith("#openqr "):
                      if msg._from in famzAdmin:
                            number = removeCmd("#openqr", text)
                            groups = bardifamz.getGroupIdsJoined()
                            try:
                                group = groups[int(number)-1]
                                G = bardifamz.getGroup(group)
                                try:
                                    G.preventedJoinByTicket = False
                                    bardifamz.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(bardifamz.reissueGroupTicket(G.id)))
                                except:
                                    G.preventedJoinByTicket = False
                                    bardifamz.updateGroup(G)
                                    gurl = "https://line.me/R/ti/g/{}".format(str(bardifamz.reissueGroupTicket(G.id)))
                                bardifamz.sendMessage(to, "「 Open Qr 」\n\nGroup : " + G.name + "\nLink: " + gurl)
                            except Exception as error:
                                bardifamz.sendMessage(to, str(error))
#==========================================
#=======BOT_KUIS================================================================================================================================
        if op.type == 25 or op.type == 26:
          try:
            msg = op.message
            text = msg.text
            receiver = msg.to
            sender = msg._from
            to = receiver
            try:
                if msg.contentType == 0:
                    if msg.toType == 2:
                    	contactlist = bardifamz.getAllContactIds()
                    	kontak = [cont.mid for cont in bardifamz.getContacts(contactlist)]
                    	for i in range(len(datakuis[to]['asw'])):
                            if text.lower() == datakuis[to]['asw'][i].lower() and datakuis[to]['saklar'] == True:
                              if receiver in gkuis:
                                if sender in kontak:
                                    wnr = bardifamz.getContact(sender).displayName
                                    wna = bardifamz.getContact(sender)
                                    if wnr in datakuis[to]['point']:
                                        datakuis[to]['point'][wnr] += 1
                                    else:
                                        datakuis[to]['point'][wnr] = 1
                                    if i != len(datakuis[to]['asw']):
                                        datakuis[to]['tmp'][i] = str(i+1)+'. '+datakuis[to]['asw'][i]+' (1)'+' ['+wnr+']'
                                        datakuis[to]['asw'][i] = datakuis[to]['asw'][i]+' (*)'
                                    else:
                                        datakuis[to]['tmp'].remove(str(datakuis[to]['tmp'][i]))
                                        datakuis[to]['tmp'].append(str(i+1)+'. '+datakuis[to]['asw'][i]+' (1)'+' ['+wnr+']')
                                        datakuis[to]['asw'].remove(str(datakuis[to]['asw'][i]))
                                        datakuis[to]['tmp'].append(datakuis[to]['asw'][i]+' (*)')
                                    rsl,rnk = '',''
                                    for j in datakuis[to]['tmp']:
                                        rsl += j+'\n'
                                    for k in datakuis[to]['point']:
                                        rnk += '>>> '+k+' : '+str(datakuis[to]['point'][k])+'\n'
                                    if '_________' in str(datakuis[to]['tmp']):
                                        isi = str(datakuis[to]['quest'])+'\n'+rsl
                                        bardifamz.sendMessage(to, isi)
                                    else:
                                        datakuis[to]['saklar'] = False
                                        isi = str(datakuis[to]['quest'])+'\n'+rsl
                                        bardifamz.sendMessage(to, isi)
                                        bardifamz.sendMessage(to, 'Papan Poin :\n'+rnk)
                                        bardifamz.sendMessage(to, 'Ketik /mulai untuk Pertanyaan Lainnya.')
                                else:
                                    bardifamz.sendMessage(to,'Anda belum menambahkan Saya sebagai teman, Untuk ikut bermain silahkan tambahkan Saya sebagai teman.')
            except Exception as error:
                logError(error)
            if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
                    if msg.toType == 0:
                        if sender != bardifamz.profile.mid:
                            to = sender
                        else:
                            to = receiver
            if text is None: return
            if text.lower() == "/mulai":
              if receiver in gkuis:
                if datakuis[to]['saklar'] == False:
                    datakuis[to]['saklar'] = True
                    getQuest(to)
                    aa = ''
                    for aswr in datakuis[to]['tmp']:
                        aa += aswr+'\n'
                        q = datakuis[to]['quest']+'\n'+aa
                    bardifamz.sendMessage(to, q)
                else:
                    aa = ''
                    for aswr in datakuis[to]['tmp']:
                        aa += aswr+'\n'
                    q = datakuis[to]['quest']+'\n'+aa
                    bardifamz.sendMessage(to, q)
                    bardifamz.sendMessage(to, 'Ketik /nyerah untuk mengakhiri pertanyaan ini.')
            elif text.lower() == '/nyerah':
              if receiver in gkuis:
                if datakuis[to]['saklar'] == True:
                    rnk,asd = '',''
                    datakuis[to]['saklar'] = False
                    for j in range(len(datakuis[to]['tmp'])):
                        if '_________' in datakuis[to]['tmp'][j]:
                            if j != len(datakuis[to]['tmp']):
                                datakuis[to]['tmp'][j] = str(j+1)+'. '+datakuis[to]['asw'][j]+' (*system)'
                            else:
                                datakuis[to]['tmp'][j].remove(str(datakuis[to]['tmp'][j]))
                                datakuis[to]['tmp'][j].append(str(j+1)+'. '+datakuis[to]['asw'][j]+' (*system)')
                    for m in datakuis[to]['tmp']:
                        asd += m+'\n'
                    for k in datakuis[to]['point']:
                        rnk += '>>> '+k+' : '+str(datakuis[to]['point'][k])+'\n'
                    zzz = str(datakuis[to]['quest'])+'\n'+asd
                    bardifamz.sendMessage(to, zzz)
                    bardifamz.sendMessage(to, 'Papan Poin :\n'+rnk)
                    bardifamz.sendMessage(to, 'Ketik /mulai untuk Pertanyaan Lainnya')
                else:
                    bardifamz.sendMessage(to, 'Game belum di mulai, tidak dapat menyerah.\nKetik /mulai untuk memulai permainan.')
            elif text.lower() == "/next":
              if receiver in gkuis:
                if datakuis[to]['saklar'] == True:
                  getQuest(to)
                  aa = ''
                  for aswr in datakuis[to]['tmp']:
                    aa += aswr+'\n'
                    q = datakuis[to]['quest']+'\n'+aa
                  bardifamz.sendMessage(to, q)
                else:
                  bardifamz.sendMessage(to, 'Permainan belum di mulai, tidak dapat berpindah ke soal berikutnya.')
            elif text.lower() == '/reset':
              if receiver in gkuis:
                datakuis[to]['point'] = {}
                datakuis[to]['saklar'] = False
                bardifamz.sendMessage(to, 'Permainan telah di reset.\nKetik /mulai untuk memulai permainan.')
            elif text.lower() == 'bye' and sender in Famzmid:
                if msg.toType == 2:
                    if datakuis[to]['saklar'] == True:
                        bardifamz.sendMessage(to, "Game belum di selesaikan, ketik /nyerah untuk menyelesaikan game dan bot akan keluar ðŸ˜Š")
                    else:
                        bardifamz.sendMessage(to, "Oke, See you next time")
                        bardifamz.leaveGroup(to)
            elif cmd == "kuis on":
                  if msg._from in admin:
                    if msg.to not in gkuis:
                      gkuis.append(msg.to)
                    bardifamz.sendMessage(msg.to, "Group Kuis Active")
            elif cmd == "kuis off":
                  if msg._from in admin:
                    if msg.to in gkuis:
                      gkuis.remove(msg.to)
                    bardifamz.sendMessage(msg.to, "Group Kuis Not Active")
            elif ("Addadmin " in msg.text):
                            if msg._from in famzAdmin:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target not in admin:
                                        admin.append(target)
                                        bardifamz.sendMessage(msg.to, "✓sᴜᴄᴄᴇss ᴀᴅᴅ ᴀᴅᴍɪɴ")
                                    else:
                                        bardifamz.sendMessage(msg.to, "sudah menjadi anggota ᴀᴅᴍɪɴ")
            elif ("Delladmin " in msg.text):
                            if msg._from in famzAdmin:
                                key = eval(msg.contentMetadata["MENTION"])
                                key["MENTIONEES"][0]["M"]
                                targets = []
                                for x in key["MENTIONEES"]:
                                    targets.append(x["M"])
                                for target in targets:
                                    if target in admin:
                                        admin.remove(target)
                                        bardifamz.sendMessage(msg.to, "✓sᴜᴄᴄᴇss Dell ᴀᴅᴍɪɴ")
                                    else:
                                        bardifamz.sendMessage(msg.to, "Bukan anggota ᴀᴅᴍɪɴ")
          except Exception as error:
              logError(error)
#===========================================================
        if op.type == 55:
            print("[ 55 ] NOTIFIED READ MESSAGE")
            try:
                if op.param1 in wait['readPoint']:
                    if op.param2 in wait['ROM1'][op.param1]:
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                    else:
                        wait['ROM1'][op.param1][op.param2] = op.param2
                        wait['setTime'][op.param1][op.param2] = op.createdTime
                        try:
                            if wait['lurkauto'] == True:
                                if len(wait['setTime'][op.param1]) % 5 == 0:
                                    anulurk(op.param1,wait)
                        except:pass
                elif op.param2 in wait['readPoints']:
                    wait['lurkt'][op.param1][op.param2][op.param3] = op.createdTime
                    wait['lurkp'][op.param1][op.param2][op.param3] = op.param2
                else:pass
            except:
                pass
        backupData()
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)

def run():
    while True:
        try:
            ops = famzPoll.singleTrace(count=50)
            if ops != None:
                for op in ops:
                   loop.run_until_complete(khieBot(op))
                   #clientBot(op)
                   famzPoll.setRevision(op.revision)
        except Exception as e:
            logError(e)

if __name__ == "__main__":
    run()